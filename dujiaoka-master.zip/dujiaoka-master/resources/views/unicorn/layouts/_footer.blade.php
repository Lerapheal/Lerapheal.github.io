<!-- footer start-->
<footer class="footer p-3">
    <div class="row">
        <div class="col-12 text-center">
            <div class="author">
                Powered by：<a href="http://dujiaoka.com">@独角数卡</a>
            </div>
            <div class="custom">
                {!! dujiaoka_config_get('footer') !!}
            </div>
        </div>
    </div>
</footer>
<!-- footer end-->
