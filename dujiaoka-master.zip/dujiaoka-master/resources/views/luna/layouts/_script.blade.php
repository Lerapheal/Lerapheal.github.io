<script>
    let tipsMsg = {
        least_one    : '{{ __('luna.least_one') }}',
        exceeds      : '{{ __('luna.exceeds') }}',
        exceeds_limit: '{{ __('luna.exceeds_limit') }}',
        mobile_order : '{{ __('luna.mobile_order') }}'
    };
</script>
<script src="/assets/luna/layui/layui.js"></script>
<script src="/assets/luna/js/jquery-3.4.1.min.js"></script>
<script src="/assets/luna/main.js"></script>
<script src="/assets/luna/layui/lay/modules/layer.js"></script>
