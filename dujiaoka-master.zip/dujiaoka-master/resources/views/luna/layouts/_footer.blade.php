<div class="footer">
    <div class="layui-row">
        <div class="layui-col-md8 layui-col-md-offset2 layui-col-sm12">
            <div style="text-align: center">{!! dujiaoka_config_get('footer') !!}</div>
            <p>Powered by <a href="https://github.com/assimon/dujiaoka" target="_blank">@独角数卡.DJK</a></p>
        </div>
    </div>
</div>
